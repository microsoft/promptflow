from promptflow import tool
from fractions import Fraction
import json

# The inputs section will change based on the arguments of the tool function, after you save the code
# Adding type to arguments and return value will help the system show the types properly
# Please update the function name/signature per need
@tool
def my_python_tool(input1: str) -> str:
  try:
    json_answer = json.loads(input1)
    answer = json_answer['answer']
  except:
    answer = input1
  
  return answer